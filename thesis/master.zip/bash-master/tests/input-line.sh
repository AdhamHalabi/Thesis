echo before calling input-line.sub
${THIS_SH} ./input-line.sub
this line for input-line.sub
echo finished with input-line.sub
